package hr.tvz.android.myweatherapp.presenter

import hr.tvz.android.myweatherapp.model.*
import kotlinx.coroutines.*

class WeatherPresenter(
    private val view: WeatherContract.View,
    private val api: WeatherApiService,
    private val apiKey: String
) : WeatherContract.Presenter {

    override fun fetchWeatherAndForecast(city: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val weatherResp = api.getCurrentWeather(city, apiKey)
                val forecastResp = api.getForecast(city, apiKey)

                if (weatherResp.isSuccessful && forecastResp.isSuccessful) {
                    val weather = weatherResp.body()
                    val forecast = forecastResp.body()

                    val weatherString = formatWeatherString(weather)
                    val forecastList = buildForecastList(forecast)

                    withContext(Dispatchers.Main) {
                        view.showWeather(weatherString)
                        view.showForecast(forecastList)
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        view.showError("Error: ${weatherResp.message()} / ${forecastResp.message()}")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    view.showError("Network Error: ${e.message}")
                }
            }
        }
    }

    override fun fetchWeatherByCoordinates(lat: Double, lon: Double) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val weatherResp = api.getCurrentWeatherByCoordinates(lat, lon, apiKey)
                val forecastResp = api.getForecastByCoordinates(lat, lon, apiKey)

                if (weatherResp.isSuccessful && forecastResp.isSuccessful) {
                    val weather = weatherResp.body()
                    val forecast = forecastResp.body()

                    val weatherString = formatWeatherString(weather)
                    val forecastList = buildForecastList(forecast)

                    withContext(Dispatchers.Main) {
                        view.showWeather(weatherString)
                        view.showForecast(forecastList)
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        view.showError("Error: ${weatherResp.message()} / ${forecastResp.message()}")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    view.showError("Network Error: ${e.message}")
                }
            }
        }
    }

    private fun formatWeatherString(weather: WeatherResponse?): String {
        return """
            ${weather?.name}
            ${weather?.weather?.get(0)?.description?.replaceFirstChar { it.uppercase() }}
            Temp: ${weather?.main?.temp}°C
            Humidity: ${weather?.main?.humidity}%
            Wind: ${weather?.wind?.speed} m/s
            Pressure: ${weather?.main?.pressure} hPa
        """.trimIndent()
    }

    private fun buildForecastList(forecast: ForecastResponse?): List<ForecastData> {
        return forecast?.list?.take(8)?.map {
            ForecastData(
                time = it.dt_txt.substring(11, 16),
                temperature = "${it.main.temp.toInt()}°C",
                iconUrl = "https://openweathermap.org/img/wn/${it.weather[0].icon}@2x.png"
            )
        } ?: emptyList()
    }
}
