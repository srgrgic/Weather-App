package hr.tvz.android.myweatherapp.model

data class GeoapifyResponse(
    val features: List<Feature>
)

data class Feature(
    val properties: Properties
)

data class Properties(
    val lat: Double,
    val lon: Double,
    val city: String?,
    val name: String,
    val country: String?
)
