package hr.tvz.android.myweatherapp.view

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import hr.tvz.android.myweatherapp.databinding.ItemForecastBinding
import hr.tvz.android.myweatherapp.model.ForecastData

class ForecastAdapter(private val items: List<ForecastData>) :
    RecyclerView.Adapter<ForecastAdapter.ForecastViewHolder>() {

    inner class ForecastViewHolder(val binding: ItemForecastBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ForecastViewHolder {
        val binding = ItemForecastBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ForecastViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ForecastViewHolder, position: Int) {
        val item = items[position]
        holder.binding.tvTime.text = item.time
        holder.binding.tvTemp.text = item.temperature
        Glide.with(holder.itemView.context)
            .load(item.iconUrl)
            .into(holder.binding.imgIcon)
    }

    override fun getItemCount() = items.size
}
