package hr.tvz.android.myweatherapp.model

data class WeatherData(
    val temperature: String,
    val description: String
)
