package hr.tvz.android.myweatherapp.model

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.Call

interface GeoapifyService {
    @GET("geocode/search")
    fun searchCities(
        @Query("text") text: String,
        @Query("apiKey") apiKey: String
    ): Call<GeoapifyResponse>
}

object GeoapifyApiService {
    val api: GeoapifyService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.geoapify.com/v1/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(GeoapifyService::class.java)
    }
}
