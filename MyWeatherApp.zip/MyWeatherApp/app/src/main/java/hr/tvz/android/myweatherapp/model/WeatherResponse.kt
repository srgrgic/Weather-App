package hr.tvz.android.myweatherapp.model

data class WeatherResponse(
    val name: String,
    val weather: List<WeatherDescription>,
    val main: Main,
    val wind: Wind
)

data class WeatherDescription(
    val description: String,
    val icon: String
)

data class Main(
    val temp: Double,
    val humidity: Int,
    val pressure: Int
)

data class Wind(
    val speed: Double
)
