package hr.tvz.android.myweatherapp.presenter

import hr.tvz.android.myweatherapp.model.ForecastData

class WeatherContract {

    interface View {
        fun showWeather(data: String)
        fun showForecast(forecastList: List<ForecastData>)
        fun showError(message: String)
    }

    interface Presenter {
        fun fetchWeatherAndForecast(city: String)
        fun fetchWeatherByCoordinates(lat: Double, lon: Double)
    }
}