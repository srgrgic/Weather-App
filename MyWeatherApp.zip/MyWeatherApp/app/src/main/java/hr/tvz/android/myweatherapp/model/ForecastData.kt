package hr.tvz.android.myweatherapp.model

data class ForecastData(
    val time: String,
    val iconUrl: String,
    val temperature: String
)