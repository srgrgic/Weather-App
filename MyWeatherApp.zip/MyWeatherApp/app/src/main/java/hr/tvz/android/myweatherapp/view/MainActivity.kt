package hr.tvz.android.myweatherapp.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import hr.tvz.android.myweatherapp.databinding.ActivityMainBinding
import hr.tvz.android.myweatherapp.model.ForecastData
import hr.tvz.android.myweatherapp.model.WeatherApiService
import hr.tvz.android.myweatherapp.presenter.WeatherContract
import hr.tvz.android.myweatherapp.presenter.WeatherPresenter

class MainActivity : AppCompatActivity(), WeatherContract.View {
    private lateinit var binding: ActivityMainBinding
    private lateinit var presenter: WeatherPresenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        presenter = WeatherPresenter(this, WeatherApiService.create(), "8f46657691eec3cc3af547da23780260")
        binding.rvForecast.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        val lat = intent.getDoubleExtra("lat", 0.0)
        val lon = intent.getDoubleExtra("lon", 0.0)

        if (lat != 0.0 && lon != 0.0) {
            presenter.fetchWeatherByCoordinates(lat, lon)
        }
    }

    override fun showWeather(data: String) {
        binding.tvWeatherData.text = data
    }

    override fun showForecast(forecastList: List<ForecastData>) {
        binding.rvForecast.adapter = ForecastAdapter(forecastList)
    }

    override fun showError(message: String) {
        binding.tvWeatherData.text = message
    }
}
