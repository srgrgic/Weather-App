package hr.tvz.android.myweatherapp.view

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import hr.tvz.android.myweatherapp.databinding.ActivitySearchBinding
import hr.tvz.android.myweatherapp.model.GeoapifyApiService
import hr.tvz.android.myweatherapp.model.GeoapifyResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SearchActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySearchBinding
    private lateinit var adapter: CityAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = CityAdapter { lat, lon, city ->
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("lat", lat)
            intent.putExtra("lon", lon)
            intent.putExtra("city", city)
            startActivity(intent)
        }

        binding.rvCities.layoutManager = LinearLayoutManager(this)
        binding.rvCities.adapter = adapter

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(query: CharSequence?, start: Int, before: Int, count: Int) {
                if (query != null && query.length > 2) {
                    GeoapifyApiService.api.searchCities(query.toString(), "1b84ede2bf294f5b9aa60ee80237cd3b")
                        .enqueue(object : Callback<GeoapifyResponse> {
                            override fun onResponse(call: Call<GeoapifyResponse>, response: Response<GeoapifyResponse>) {
                                if (response.isSuccessful) {
                                    Log.d("Geoapify", "Response OK")
                                    Log.d("Geoapify", "Result: ${response.body()}")

                                    val results = response.body()?.features?.map {
                                        val props = it.properties
                                        val cityName = props.city ?: props.name
                                        val country = props.country ?: ""
                                        Triple(props.lat, props.lon, "$cityName, $country")
                                    } ?: emptyList()

                                    adapter.submitList(results)
                                } else {
                                    Log.e("Geoapify", "Response error: ${response.code()}")
                                }
                            }

                            override fun onFailure(call: Call<GeoapifyResponse>, t: Throwable) {
                                Log.e("Geoapify", "API call failed: ${t.message}")
                            }
                        })
                }
            }
        })
    }
}
