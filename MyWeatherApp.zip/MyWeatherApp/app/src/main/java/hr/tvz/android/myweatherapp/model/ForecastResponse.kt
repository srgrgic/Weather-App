package hr.tvz.android.myweatherapp.model

data class ForecastResponse(
    val list: List<ForecastEntry>
)

data class ForecastEntry(
    val dt_txt: String,
    val main: Main,
    val weather: List<WeatherDescription>
)
