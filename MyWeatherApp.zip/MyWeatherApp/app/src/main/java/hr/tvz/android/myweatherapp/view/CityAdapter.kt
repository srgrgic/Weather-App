package hr.tvz.android.myweatherapp.view

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import hr.tvz.android.myweatherapp.databinding.ItemCityBinding

class CityAdapter(private val onClick: (Double, Double, String) -> Unit) :
    RecyclerView.Adapter<CityAdapter.CityViewHolder>() {

    private var cities: List<Triple<Double, Double, String>> = emptyList()

    fun submitList(newCities: List<Triple<Double, Double, String>>) {
        cities = newCities
        notifyDataSetChanged()
    }

    inner class CityViewHolder(private val binding: ItemCityBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(city: Triple<Double, Double, String>) {
            binding.tvCityName.text = city.third  // Grad + država formatirano
            binding.root.setOnClickListener {
                onClick(city.first, city.second, city.third)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CityViewHolder {
        val binding = ItemCityBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CityViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CityViewHolder, position: Int) {
        holder.bind(cities[position])
    }

    override fun getItemCount(): Int = cities.size
}