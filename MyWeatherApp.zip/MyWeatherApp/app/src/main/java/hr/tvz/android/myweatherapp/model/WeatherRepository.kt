package hr.tvz.android.myweatherapp.model

class WeatherRepository {
}